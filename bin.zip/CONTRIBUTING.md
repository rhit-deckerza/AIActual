Please review the contributing documentation on our website: https://actualbudget.org/docs/contributing/
