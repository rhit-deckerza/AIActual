export const NON_DRAGGABLE_AREA_CLASS_NAME = 'non-draggable-area';
