import { createContext } from 'react';

export const NamespaceContext = createContext<string | undefined>(undefined);
