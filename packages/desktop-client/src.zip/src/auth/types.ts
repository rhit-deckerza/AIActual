export enum Permissions {
  ADMINISTRATOR = 'ADMIN',
}
